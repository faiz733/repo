<?php

namespace App\Repository;

interface IQuoteRepo {

    function all();
}